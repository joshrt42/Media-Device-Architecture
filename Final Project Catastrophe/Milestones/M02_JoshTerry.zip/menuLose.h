
//{{BLOCK(menuLose)

//======================================================================
//
//	menuLose, 512x256@4, 
//	+ palette 256 entries, not compressed
//	+ 182 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 64x32 
//	Total size: 512 + 5824 + 4096 = 10432
//
//	Time-stamp: 2017-11-21, 20:44:27
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_MENULOSE_H
#define GRIT_MENULOSE_H

#define menuLoseTilesLen 5824
extern const unsigned short menuLoseTiles[2912];

#define menuLoseMapLen 4096
extern const unsigned short menuLoseMap[2048];

#define menuLosePalLen 512
extern const unsigned short menuLosePal[256];

#endif // GRIT_MENULOSE_H

//}}BLOCK(menuLose)
