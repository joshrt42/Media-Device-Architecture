/******************************************************************************
Author:     Josh Terry
Project:    CS 2261 Final project
File:       game.h
Date:       21 November 2017

******************************************************************************/




// ================ STRUCTS =================

// Player Struct
typedef struct {
    int col;
    int row;
    int oldCol;
    int cdel;
    int rdel;
    int height;
    int width;
    int active;
    int health;
    int aniCounter;
    int aniState;
    int curFrame;
    int numFrames;
    int facing;
} PLAYER;

// Enemy Struct
typedef struct {
    int row;
    int col;
    int oldRow;
    int oldCol;
    int rdel;
    int cdel;
    int height;
    int width;
    int active;
    int erased;
    u8 sprite;
    int aniCounter;
    int curFrame;
    int numFrames;
    int spriteNo;
} CAT;


// ================== VARS ==================

#define PLAYERBULLETCOUNT 5
#define CATCOUNT 30

extern PLAYER player;
extern CAT Cats[CATCOUNT];
extern int enemiesRemaining;
extern int gameOver;
extern int gameWon;
extern int score;



// ============== PROTOTYPES ================

void initGame();
void updateGame();
void drawGame();

void initPlayer();
void updatePlayer();
void drawPlayer();
void drawHealth();
void drawScore();
void drawTime();

void initCats();
void updateCat(CAT *);
void drawCat(CAT *);