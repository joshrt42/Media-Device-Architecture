
//{{BLOCK(menuTitle)

//======================================================================
//
//	menuTitle, 512x256@4, 
//	+ palette 256 entries, not compressed
//	+ 178 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 64x32 
//	Total size: 512 + 5696 + 4096 = 10304
//
//	Time-stamp: 2017-11-21, 19:57:49
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_MENUTITLE_H
#define GRIT_MENUTITLE_H

#define menuTitleTilesLen 5696
extern const unsigned short menuTitleTiles[2848];

#define menuTitleMapLen 4096
extern const unsigned short menuTitleMap[2048];

#define menuTitlePalLen 512
extern const unsigned short menuTitlePal[256];

#endif // GRIT_MENUTITLE_H

//}}BLOCK(menuTitle)
