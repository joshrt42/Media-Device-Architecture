/******************************************************************************
Author:		Josh Terry
Project:	CS 2261 Final
File:		main.c
Date:		21 November 2017

******************************************************************************/


/*
   _____          __  __ ______ _____  _           __     __
  / ____|   /\   |  \/  |  ____|  __ \| |        /\\ \   / /
 | |  __   /  \  | \  / | |__  | |__) | |       /  \\ \_/ / 
 | | |_ | / /\ \ | |\/| |  __| |  ___/| |      / /\ \\   /  
 | |__| |/ ____ \| |  | | |____| |    | |____ / ____ \| |   
  \_____/_/    \_\_|  |_|______|_|    |______/_/    \_\_|  

So I made a pretty huge departure from my last project idea.
This is most similar to Dino Run, with elements of Frogger and Contra.

The player is a mouse. Cats are falling from the sky.
The player must find the parts of and build and anti-cat-gravity device to survive.

Win condition: Find all pieces, bring them back to home.
Loss condition: run out of time or touch a cat. Cats Fall from the sky and walk around.

Have implemented:
	Character sprite animations
	Gravity
	Player movement
	A sort of parallax effect
	Backgrounds
	State engine with help state. (Still need to add actual instructions in-game to help state)

Currently, I've got a bunch left to do. I spent tons of time on backgrounds and sprites for M02.
Need to implement a wide, scrolling background with the player's home in the bottom left
Will allow player to carry one item back to home at a time
Will implement cats that fall from the sky and begin walking around every 10 seconds
Will implement some cats that spawn when the game state begins
Will implement a means of platforming using a collision map
Will implement a worldRow, worldCol, screenRow, screenCol for player, etc.
Will imlpement sound effects and music when game is bug-free and done.
Need to make sprites for cats, items, etc.
	Cats will be big boys btw. Like medium wide sprites big boys.
Need to fix lose background

Definitely planning on going to office hours some and asking plenty of questions during class.
*/




/*
  _______ ____  _____   ____    
 |__   __/ __ \|  __ \ / __ \ _ 
    | | | |  | | |  | | |  | (_)
    | | | |  | | |  | | |  | |  
    | | | |__| | |__| | |__| |_ 
    |_|  \____/|_____/ \____/(_)

	CATACLYSM!
		You are a mouse. Cats are falling from the sky
		Gather the pieces of the anti-cat-gravity device!
		Bring them back to your home!
		Don't touch cats!
	OBJECTIVE
		Run left to right. Dodge cats
		Display
			Time remaining upper right
			Distance remaining upper right under time
			Score upper left
			Lives lower left with icon x number
	STATES
		START
			BG0: Foreground with a mouse running from cat toward hole
			BG1: Same ground as other stationary screens. Mountains in BG
			BG2: Cats falling from sky
			Sprites: Player mouse idle next to words
		GAME
			BG0: Map itself. Grassy with fallen trees to jump over
			BG1: Mountains
			BG2: Firey background rising
			Sprites: Player. Cats falling. Cats walking toward player. Scores.
		PAUSE
			BG0: Pause in big letters; cats on top; mouse between letters
			BG1: Same ground as other stationary screens. Mountains in BG
			BG2: Cats falling from sky
			Sprites: Player mouse idle next to words
		WIN
			BG0: Win in big letters, crushing cat.
			BG1: Same ground as other stationary screens. Mountains in BG
			BG2: blue sky moving left to right with clouds
			Sprites: Player mouse idle on top of words
		LOSE
			BG0: Mouse crushed by letters. Cats on top and on ground
			BG1: Same ground as other stationary screens. Mountains in BG
			BG2: Cats falling from sky with fire
		HELP
			BG0: Mouse scratching head next to big stone tablet w/ text in center
			BG1: Same ground as other stationary screens. Mountains in BG
			BG2: Cats falling from sky
	
	BACKGROUNDS
		x Grassy ground w/ mountains in BG - Start, pause, win, lose, help
		x Cats falling from blue sky - Start, pause, help
		  Cats falling from fire sky - Lose
		  Level map - Game
		  Parallaxed mountains - Game
		  Cats falling in wide blue sky - 
		x CATastrophe - Start
		  PAUSE - Pause
		  Tablet with words - Help
		  LOSE - lose
		  WIN - win

	SPRITES
		Player
			Idle animation
			Running animation
			Jump animation
			Fall animation
			Attack animation
			Crouch animation
		Cat
			Idle animation
			Walk animation		

	PLAYER

	ENEMIES

	COLLISION MAP
*/

#include <stdlib.h>
#include <stdio.h>
#include "myLib.h"
#include "game.h"
#include "spriteSheet.h"
#include "fallingCats.h"
#include "grassyBG.h"
#include "menuTitle.h"
#include "menuPause.h"
#include "menuWin.h"
#include "menuLose.h"
#include "lostCats.h"

//Backgrounds



// ============================================== PROTOTYPES ==================

void initialize();
void gotoStart();
void start();
void gotoGame();
void game();
void gotoPause();
void pause();
void gotoWin();
void win();
void gotoLose();
void lose();
void gotoHelp();
void help();




// ============================================== DEFINITIONS =================

// States
enum {START, GAME, PAUSE, WIN, LOSE, HELP};
int state;

// Button Variables
unsigned short buttons;
unsigned short oldButtons;

// Some visual things
int hOff = 0;
int vOff = 0;

// ShadowOAM
OBJ_ATTR shadowOAM[128];



// ============================================== MAIN ========================

int main() {

    initialize();

    while(1) {

        // Update button variables
        oldButtons = buttons;
        buttons = BUTTONS;

        // State Machine
        switch(state) {

            case START:
                start();
                break;
            case GAME:
                game();
                break;
            case PAUSE:
                pause();
                break;
            case WIN:
                win();
                break;
            case LOSE:
                lose();
                break;
            case HELP:
            	help();
            	break;
        }
    }
}

// Initializes the GBA itself
void initialize() {
	//Load BG palette
	loadPalette(menuPausePal);

	//Load BG0 start tiles and maps.
	REG_BG0CNT = BG_SIZE_WIDE | BG_CHARBLOCK(0) | BG_SCREENBLOCK(30);
	DMANow(3, menuTitleTiles, &CHARBLOCK[0], menuTitleTilesLen/2);
	DMANow(3, menuTitleMap, &SCREENBLOCK[30], menuTitleMapLen/2);

	//Load BG1 tiles and maps.
	REG_BG1CNT = BG_SIZE_WIDE | BG_CHARBLOCK(1) | BG_SCREENBLOCK(28);
	DMANow(3, grassyBGTiles, &CHARBLOCK[1], grassyBGTilesLen/2);
	DMANow(3, grassyBGMap, &SCREENBLOCK[28], grassyBGMapLen/2);

	//Load BG2 tiles and maps.
	REG_BG2CNT = BG_SIZE_TALL | BG_CHARBLOCK(2) | BG_SCREENBLOCK(26);
	DMANow(3, fallingCatsTiles, &CHARBLOCK[2], fallingCatsTilesLen/2);
	DMANow(3, fallingCatsMap, &SCREENBLOCK[26], fallingCatsMapLen/2);

	//Load sprite tiles and palette into their spaces
	DMANow(3, spriteSheetTiles, &CHARBLOCK[4], spriteSheetTilesLen/2);
	DMANow(3, spriteSheetPal, SPRITEPALETTE, 256);

	//Hide all sprites
	hideSprites();

	//Enable sprites and set up background 0
	REG_DISPCTL = MODE0 | BG0_ENABLE | BG1_ENABLE | BG2_ENABLE | SPRITE_ENABLE;

	gotoStart();
}




// ============================================== START =======================

// Sets up start state
void gotoStart() {
	vOff = 0;
	hOff = 0;
	REG_BG0VOFF = 0;
	REG_BG0HOFF = 0;
	REG_BG1VOFF = 0;
	REG_BG1HOFF = 0;
	REG_BG2VOFF = 0;
	REG_BG2HOFF = 0;
	gameOver = 0;
	gameWon = 0;
	score = 0;


	//Load BG palette
	loadPalette(menuPausePal);

	//Load BG0 start tiles and maps.
	DMANow(3, menuTitleTiles, &CHARBLOCK[0], menuTitleTilesLen/2);
	DMANow(3, menuTitleMap, &SCREENBLOCK[30], menuTitleMapLen/2);

	//Load grassy background tiles and maps.
	DMANow(3, grassyBGTiles, &CHARBLOCK[1], grassyBGTilesLen/2);
	DMANow(3, grassyBGMap, &SCREENBLOCK[28], grassyBGMapLen/2);

	//Load Falling cats tiles and maps.
	DMANow(3, fallingCatsTiles, &CHARBLOCK[2], fallingCatsTilesLen/2);
	DMANow(3, fallingCatsMap, &SCREENBLOCK[26], fallingCatsMapLen/2);

	//Load sprite tiles and palette into their spaces
	DMANow(3, spriteSheetTiles, &CHARBLOCK[4], spriteSheetTilesLen/2);
	DMANow(3, spriteSheetPal, SPRITEPALETTE, 256);

	//Hide all sprites
	hideSprites();

	//Wait for VBlank
	waitForVBlank();

	state = START;
}

// Runs every frame during start state
void start() {

	waitForVBlank();

	vOff--;
	REG_BG2VOFF=vOff;

	if (BUTTON_PRESSED(BUTTON_START)) {

		initGame();
		gotoGame();
	} else if (BUTTON_PRESSED(BUTTON_SELECT)) {

		gotoHelp();
	}
}




// ============================================== GAME ========================

// Sets up game state
void gotoGame() {
	vOff = 0;
	hOff = 0;
	REG_BG0VOFF = 0;
	REG_BG0HOFF = 0;
	REG_BG1VOFF = 0;
	REG_BG1HOFF = 0;
	REG_BG2VOFF = 0;
	REG_BG2HOFF = 0;
	//Load Palette

	//Change Background

	//Load BG0 start tiles and maps.
	DMANow(3, menuTitleTiles, &CHARBLOCK[0], menuTitleTilesLen/2);
	DMANow(3, menuTitleMap, &SCREENBLOCK[30], menuTitleMapLen/2);

	//Load grassy background tiles and maps.
	DMANow(3, grassyBGTiles, &CHARBLOCK[1], grassyBGTilesLen/2);
	DMANow(3, grassyBGMap, &SCREENBLOCK[28], grassyBGMapLen/2);

	//Load Falling cats tiles and maps.
	DMANow(3, fallingCatsTiles, &CHARBLOCK[2], fallingCatsTilesLen/2);
	DMANow(3, fallingCatsMap, &SCREENBLOCK[26], fallingCatsMapLen/2);

	waitForVBlank();

	state = GAME;
}

// Runs every frame during game state
void game() {

	waitForVBlank();
	

	vOff--;

	REG_BG0HOFF = hOff/2;

	REG_BG1HOFF = hOff/4;

	REG_BG2VOFF = vOff;
	REG_BG2HOFF = hOff/8;

	updateGame();
	drawGame();
    DMANow(3, shadowOAM, OAM, 128*4);

    if (BUTTON_HELD(BUTTON_LEFT))
    	hOff--;
    if (BUTTON_HELD(BUTTON_RIGHT))
    	hOff++;

    if (BUTTON_PRESSED(BUTTON_START))
        gotoPause();
    else if (BUTTON_PRESSED(BUTTON_A))
        gotoWin();
    else if (BUTTON_PRESSED(BUTTON_B))
        gotoLose();
}




// ============================================== PAUSE =======================

// Sets up pause state
void gotoPause() {
	REG_BG0VOFF = 0;
	REG_BG0HOFF = 0;
	REG_BG1VOFF = 0;
	REG_BG1HOFF = 0;
	REG_BG2VOFF = 0;
	REG_BG2HOFF = 0;
	//Load Palette
	loadPalette(menuPausePal);

	//Change Backgrounds
	//Load pause title thing
	DMANow(3, menuPauseTiles, &CHARBLOCK[0], menuPauseTilesLen/2);
	DMANow(3, menuPauseMap, &SCREENBLOCK[30], menuPauseMapLen/2);

	//Load grassy background tiles and maps.
	DMANow(3, grassyBGTiles, &CHARBLOCK[1], grassyBGTilesLen/2);
	DMANow(3, grassyBGMap, &SCREENBLOCK[28], grassyBGMapLen/2);

	//Load Falling cats tiles and maps.
	DMANow(3, fallingCatsTiles, &CHARBLOCK[2], fallingCatsTilesLen/2);
	DMANow(3, fallingCatsMap, &SCREENBLOCK[26], fallingCatsMapLen/2);

	waitForVBlank();
	hideSprites();

	state = PAUSE;
}

// Runs every frame during pause
void pause() {

	vOff--;
	REG_BG2VOFF=vOff;

	waitForVBlank();

    if (BUTTON_PRESSED(BUTTON_START))
        gotoGame();
    else if (BUTTON_PRESSED(BUTTON_SELECT))
        gotoStart();
}




// ============================================== WIN =========================

// Sets up win state
void gotoWin() {
	vOff = 0;
	hOff = 0;
	REG_BG0VOFF = 0;
	REG_BG0HOFF = 0;
	REG_BG1VOFF = 0;
	REG_BG1HOFF = 0;
	REG_BG2VOFF = 0;
	REG_BG2HOFF = 0;
	//Load Palette
	loadPalette(menuPausePal);

	//Change Background
	//Load win title thing
	DMANow(3, menuWinTiles, &CHARBLOCK[0], menuWinTilesLen/2);
	DMANow(3, menuWinMap, &SCREENBLOCK[30], menuWinMapLen/2);

	//Load grassy background tiles and maps.
	DMANow(3, grassyBGTiles, &CHARBLOCK[1], grassyBGTilesLen/2);
	DMANow(3, grassyBGMap, &SCREENBLOCK[28], grassyBGMapLen/2);

	//Load Falling cats tiles and maps.
	DMANow(3, fallingCatsTiles, &CHARBLOCK[2], fallingCatsTilesLen/2);
	DMANow(3, fallingCatsMap, &SCREENBLOCK[26], fallingCatsMapLen/2);

	waitForVBlank();
	hideSprites();

	state = WIN;
}

// Runs every frame during win state
void win() {

	vOff++;
	REG_BG2VOFF=vOff;

	waitForVBlank();

    if (BUTTON_PRESSED(BUTTON_START))
        gotoStart();
}




// ============================================== LOSE ========================

// Sets up lose state
void gotoLose() {
	vOff = 0;
	hOff = 0;
	REG_BG0VOFF = 0;
	REG_BG0HOFF = 0;
	REG_BG1VOFF = 0;
	REG_BG1HOFF = 0;
	REG_BG2VOFF = 0;
	REG_BG2HOFF = 0;
	//Load Palette
	loadPalette(menuLosePal);

	//Change Background
	//Load win title thing
	DMANow(3, menuLoseTiles, &CHARBLOCK[0], menuLoseTilesLen/2);
	DMANow(3, menuLoseMap, &SCREENBLOCK[30], menuLoseMapLen/2);

	//Load grassy background tiles and maps.
	DMANow(3, 0, &CHARBLOCK[1], grassyBGTilesLen/2);
	DMANow(3, 0, &SCREENBLOCK[28], grassyBGMapLen/2);

	//Load Falling cats tiles and maps.
	DMANow(3, lostCatsTiles, &CHARBLOCK[2], lostCatsTilesLen/2);
	DMANow(3, lostCatsMap, &SCREENBLOCK[26], lostCatsMapLen/2);

	waitForVBlank();
	hideSprites();

	state = LOSE;
}

// Runs every frame during lose state
void lose() {

	waitForVBlank();
	vOff -= 2;
	REG_BG2VOFF=vOff;

    if (BUTTON_PRESSED(BUTTON_START))
        gotoStart();
}




// ============================================== HELP ========================

// Sets up help state
void gotoHelp() {
	vOff = 0;
	hOff = 0;
	REG_BG0VOFF = 0;
	REG_BG0HOFF = 0;
	REG_BG1VOFF = 0;
	REG_BG1HOFF = 0;
	REG_BG2VOFF = 0;
	REG_BG2HOFF = 0;
    
	//Load Palette
	//Change Background

	//Load grassy background tiles and maps.
	DMANow(3, grassyBGTiles, &CHARBLOCK[1], grassyBGTilesLen/2);
	DMANow(3, grassyBGMap, &SCREENBLOCK[28], grassyBGMapLen/2);

	//Load Falling cats tiles and maps.
	DMANow(3, fallingCatsTiles, &CHARBLOCK[2], fallingCatsTilesLen/2);
	DMANow(3, fallingCatsMap, &SCREENBLOCK[26], fallingCatsMapLen/2);

	waitForVBlank();
	hideSprites();

	state = HELP;
}

// Runs every frame during help state
void help() {

	vOff--;
	REG_BG2VOFF=vOff;

	waitForVBlank();

    if (BUTTON_PRESSED(BUTTON_START) |
    	BUTTON_PRESSED(BUTTON_SELECT) |
    	BUTTON_PRESSED(BUTTON_A) | 
    	BUTTON_PRESSED(BUTTON_B) |
    	BUTTON_PRESSED(BUTTON_LEFT) |
    	BUTTON_PRESSED(BUTTON_RIGHT) |
    	BUTTON_PRESSED(BUTTON_DOWN) | 
    	BUTTON_PRESSED(BUTTON_UP) |
    	BUTTON_PRESSED(BUTTON_L) |
    	BUTTON_PRESSED(BUTTON_R))
        gotoStart();
}