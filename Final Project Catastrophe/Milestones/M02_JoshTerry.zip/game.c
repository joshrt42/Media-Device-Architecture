/******************************************************************************
Author:     Josh Terry
Project:    CS 2261 Final
File:       game.c
Date:       21 November 2017

******************************************************************************/




// ================= INCLUDE ===================

#include <stdlib.h>
#include "myLib.h"
#include "game.h"
#include "spriteSheet.h"



// ================= VARS ======================

PLAYER player;
CAT cats[];

int gameOver = 0;
int gameWon = 0;
int score = 0;


// ================= GAME FUNCS ================

//Initialize the game
void initGame() {

    initPlayer();
    initCats();
}

//Update the game each frame
void updateGame() {

    updatePlayer();

    for (u8 i = 0; i < CATCOUNT; i++)
        updateCat(&cats[i]);
}

//Draw the game each frame
void drawGame() {

    drawHealth();
    drawScore();
    drawPlayer();
    drawTime();

    for (u8 i = 0; i < CATCOUNT; i++)
        drawCat(&cats[i]);
}




// ================= PLAYER FUNCS ==============

//Initialize the player
void initPlayer() {
    player.col = SCREENWIDTH/2 - 20;
    player.row = 130;
    player.cdel = 1;
    player.rdel = 0;
    player.height = 16;
    player.width = 16;
    player.active = 1;
    player.health = 3;
    player.aniCounter = 0;
    player.aniState = 0;
    player.curFrame = 0;
    player.numFrames = 13;
    player.facing = 0;
}

//Handle every-frame actions of the player
void updatePlayer() {
    if (player.active) {

        //Control movement
        if (BUTTON_HELD(BUTTON_LEFT) && player.col > 1) {
            player.facing = 0;
            player.col -= player.cdel;
            player.numFrames = 7;
            player.aniState = 1;
            if (player.aniCounter % 3 == 0) {
                player.curFrame = (player.curFrame + 1) % player.numFrames;
            }
            player.aniCounter++;
        } else if (BUTTON_HELD(BUTTON_RIGHT) && player.col < SCREENWIDTH - player.width ) {
            player.facing = 1;
            player.col += player.cdel;
            player.numFrames = 7;
            player.aniState = 1;
            if (player.aniCounter % 3 == 0) {
                player.curFrame = (player.curFrame + 1) % player.numFrames;
            }
            player.aniCounter++;
        } else {
            player.numFrames = 13;
            player.aniState = 0;
            if (player.aniCounter % 15 == 0) {
                player.curFrame = (player.curFrame + 1) % player.numFrames;
            }
            player.aniCounter++;
        }

        if (BUTTON_HELD(BUTTON_UP) && player.row > 129) {
            player.rdel = -20;
        }

        if (player.rdel < 0) {
            player.row += player.rdel/4;
            player.rdel++;
        } else if (player.rdel == 0 && player.row != 130) {
            player.rdel++;
        } else if (player.rdel > 0) {
            if (player.row < 129) {
                player.row += player.rdel/4;
                player.rdel++;
            } else {
                player.row = 130;
                player.rdel = 0;
            }
        }
    }
}

//Draw the player
void drawPlayer() {
    //Edit first bucket of shadowOAM
    if (player.active) {
        shadowOAM[0].attr0 = player.row | ATTR0_SQUARE | ATTR0_REGULAR;
        shadowOAM[0].attr1 = player.col | ATTR1_SMALL;
        if (player.facing)
            shadowOAM[0].attr1 |= ATTR1_HFLIP;
        shadowOAM[0].attr2 = ATTR2_TILEID(player.curFrame*2, 2*player.aniState);
    }

}

//Draws the player's health
void drawHealth() {
}

//Draws the player's score
void drawScore() {
}

//Draws the player's time remaining
void drawTime() {
}




// ================= CAT FUNCS ===============

//Initialize the fallCats
void initCats() {

    for (u8 i = 0; i < CATCOUNT; i++) {
    }
}

//Handle every-frame actions of fallCats
void updateCat(CAT* e) {
}

//Draw a CAT
void drawCat(CAT* e) {
}