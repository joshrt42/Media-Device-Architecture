
//{{BLOCK(menuHelp)

//======================================================================
//
//	menuHelp, 512x256@4, 
//	+ palette 256 entries, not compressed
//	+ 63 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 64x32 
//	Total size: 512 + 2016 + 4096 = 6624
//
//	Time-stamp: 2017-11-29, 00:55:44
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_MENUHELP_H
#define GRIT_MENUHELP_H

#define menuHelpTilesLen 2016
extern const unsigned short menuHelpTiles[1008];

#define menuHelpMapLen 4096
extern const unsigned short menuHelpMap[2048];

#define menuHelpPalLen 512
extern const unsigned short menuHelpPal[256];

#endif // GRIT_MENUHELP_H

//}}BLOCK(menuHelp)
