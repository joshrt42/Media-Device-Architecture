
//{{BLOCK(fallingCats)

//======================================================================
//
//	fallingCats, 256x512@4, 
//	+ palette 256 entries, not compressed
//	+ 311 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x64 
//	Total size: 512 + 9952 + 4096 = 14560
//
//	Time-stamp: 2017-11-21, 17:38:50
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_FALLINGCATS_H
#define GRIT_FALLINGCATS_H

#define fallingCatsTilesLen 9952
extern const unsigned short fallingCatsTiles[4976];

#define fallingCatsMapLen 4096
extern const unsigned short fallingCatsMap[2048];

#define fallingCatsPalLen 512
extern const unsigned short fallingCatsPal[256];

#endif // GRIT_FALLINGCATS_H

//}}BLOCK(fallingCats)
