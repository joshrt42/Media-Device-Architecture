/******************************************************************************
Author:     Josh Terry
Project:    CS 2261 Final project
File:       game.h
Date:       28 November 2017

******************************************************************************/




// ================ STRUCTS =================

// Player Struct
typedef struct {
    int worldCol;
    int worldRow;
    int screenCol;
    int screenRow;
    int cdel;
    int rdel;
    int height;
    int width;
    int active;
    int aniCounter;
    int aniState;
    int curFrame;
    int numFrames;
    int facing;
    int health;
    int cheeseCount;
} PLAYER;

// Enemy Struct
typedef struct {
    int worldRow;
    int worldCol;
    int screenRow;
    int screenCol;
    int rdel;
    int cdel;
    int height;
    int width;
    int active;
    int aniCounter;
    int curFrame;
    int numFrames;
    int spriteNo;
    int facing;
    int catNo;
    int hide;
} CAT;

//Cheese Struct
typedef struct {
    int worldRow;
    int screenRow;
    int worldCol;
    int screenCol;
    int height;
    int width;
    int active;
    int hide;
    int cheeseNo;
} CHEESE;

// ================== VARS ==================

#define PLAYERBULLETCOUNT 5
#define CATCOUNT 6
#define CHEESECOUNT 9

extern PLAYER player;
extern CAT cats[CATCOUNT];
extern CHEESE cheese[CHEESECOUNT];
extern int cheeseRemaining;
extern int timeRemaining;
extern int timeRemainingCounter;
extern int gameOver;
extern int gameWon;
extern int score;
extern int playerOAM;
extern int baseOAM;
extern int itemOAM;
extern int attackOAM;
extern int catAttackOAM;
extern int enemyOAM;
extern int timeOAM;
extern int healthOAM;



// ============== PROTOTYPES ================

void initGame();
void updateGame();
void drawGame();

void initPlayer();
void updatePlayer();
void drawPlayer();
void drawHealth();
void drawScore();
void drawTime();

void initCats();
void updateCat(CAT *);
void drawCat(CAT *);

void initCheese();
void updateCheese(CHEESE *);
void drawCheese(CHEESE *);
void drawCheeseRemaining();