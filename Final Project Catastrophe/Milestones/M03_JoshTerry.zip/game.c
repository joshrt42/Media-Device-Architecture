/******************************************************************************
Author:     Josh Terry
Project:    CS 2261 Final
File:       game.c
Date:       28 November 2017

******************************************************************************/




// ================= INCLUDE ===================

#include <stdlib.h>
#include "soundProcessing.h"
#include "spriteSheet.h"
#include "myLib.h"
#include "game.h"
#include "soundCat.h"
#include "cheeseCollected.h"



// ================= VARS ======================

PLAYER player;
CAT cats[];
CHEESE cheese[];

int gameOver = 0;
int gameWon = 0;
int score = 0;
int timeRemaining = 60;
int timeRemainingCounter = 0;
int cheeseRemaining = CHEESECOUNT;



// ================= OAM INDICES ===============
int playerOAM = 0;
int baseOAM = 1;
int cheeseOAM = 2;
int catAttackOAM = 11;
int enemyOAM = 21;
int timeOAM = 46;
int healthOAM = 51;
int cheeseRemOAM = 54;



// ================= GAME FUNCS ================

//Initialize the game
void initGame() {

    initPlayer();
    initCats();
    initCheese();

    gameOver = 0;
    gameWon = 0;
    score = 0;
    timeRemaining = 60;
    timeRemainingCounter = 0;
    cheeseRemaining = CHEESECOUNT;
}

//Update the game each frame
void updateGame() {

    updatePlayer();

    for (u8 i = 0; i < CATCOUNT; i++)
        updateCat(&cats[i]);

    for (u8 i = 0; i < CHEESECOUNT; i++)
        updateCheese(&cheese[i]);

    if (timeRemainingCounter++ > 60) {
        if (timeRemaining <= 0) {
            gameOver = 1;
        }
        timeRemainingCounter = 0;
        timeRemaining -= 1;
    }

    if (cheeseRemaining == 0) {
        gameWon = 1;
    }
}

//Draw the game each frame
void drawGame() {

    drawHealth();
    drawScore();
    drawPlayer();
    drawTime();
    drawCheeseRemaining();


    for (u8 i = 0; i < CHEESECOUNT; i++)
        drawCheese(&cheese[i]);

    for (u8 i = 0; i < CATCOUNT; i++) {
        drawCat(&cats[i]);
    }
}




// ================= PLAYER FUNCS ==============

//Initialize the player
void initPlayer() {
    player.worldCol = 16;
    player.worldRow = 135;
    player.screenRow = player.worldRow;
    player.screenCol = player.worldCol;
    player.cdel = 1;
    player.rdel = 0;
    player.height = 16;
    player.width = 16;
    player.active = 1;
    player.health = 3;
    player.aniCounter = 0;
    player.aniState = 0;
    player.curFrame = 0;
    player.numFrames = 13;
    player.facing = 0;
    player.cheeseCount = 0;
}

//Handle every-frame actions of the player
void updatePlayer() {
    if (player.active) {

        //Control movement
        if (BUTTON_PRESSED(BUTTON_RIGHT) || BUTTON_PRESSED(BUTTON_LEFT))
            player.curFrame = 0;
        if (BUTTON_HELD(BUTTON_LEFT) && player.worldCol > -1) {
            player.facing = 0;
            player.worldCol -= player.cdel;
            player.numFrames = 7;
            player.aniState = 1;
            if (player.aniCounter % 3 == 0) {
                player.curFrame = (player.curFrame + 1) % player.numFrames;
            }
            player.aniCounter++;
        } else if (BUTTON_HELD(BUTTON_RIGHT) && player.worldCol < 768 - player.width ) {
            player.facing = 1;
            player.worldCol += player.cdel;
            player.numFrames = 7;
            player.aniState = 1;
            if (player.aniCounter % 3 == 0) {
                player.curFrame = (player.curFrame + 1) % player.numFrames;
            }
            player.aniCounter++;
        } else {
            player.numFrames = 7;
            player.aniState = 0;
            if (player.aniCounter % 12 == 0) {
                player.curFrame = (player.curFrame + 1) % player.numFrames;
            }
            player.aniCounter++;
        }

        if (BUTTON_HELD(BUTTON_UP) && player.worldRow > 134) {
            player.rdel = -20;
        }

        if (player.rdel < 0) {
            player.worldRow += player.rdel/4;
            player.rdel++;
        } else if (player.rdel == 0 && player.worldRow != 135) {
            player.rdel++;
        } else if (player.rdel > 0) {
            if (player.worldRow < 134) {
                player.worldRow += player.rdel/4;
                player.rdel++;
            } else {
                player.worldRow = 135;
                player.rdel = 0;
            }
        }

        if (BUTTON_PRESSED(BUTTON_B) && player.health < 9)
            player.health++;
        if (player.health < 1)
            gameOver = 1;
    }
}

//Draw the player
void drawPlayer() {
    //Edit first bucket of shadowOAM
    if (player.active) {
        shadowOAM[playerOAM].attr0 = (player.screenRow & ROWMASK) | ATTR0_SQUARE | ATTR0_REGULAR;
        shadowOAM[playerOAM].attr1 = (player.screenCol & COLMASK) | ATTR1_SMALL;
        if (player.facing)
            shadowOAM[playerOAM].attr1 |= ATTR1_HFLIP;
        shadowOAM[playerOAM].attr2 = ATTR2_TILEID(player.curFrame*2, 2*player.aniState);
    }
}

//Draws the player's health
void drawHealth() {
    if (player.active) {
        shadowOAM[healthOAM + 1].attr0 = 8 | ATTR0_WIDE | ATTR0_REGULAR;
        shadowOAM[healthOAM + 1].attr1 = (SCREENWIDTH - 20) | ATTR1_TINY;
        shadowOAM[healthOAM + 1].attr2 = ATTR2_TILEID(10, 4);

        shadowOAM[healthOAM].attr0 = 8 | ATTR0_SQUARE | ATTR0_REGULAR;
        shadowOAM[healthOAM].attr1 = (SCREENWIDTH - 8) | ATTR1_TINY;
        shadowOAM[healthOAM].attr2 = ATTR2_TILEID(player.health, 4);
    }
}

//Draws the player's score
void drawScore() {
}

//Draws the player's time remaining
void drawTime() {
    shadowOAM[timeOAM].attr0 = 0 | ATTR0_WIDE | ATTR0_REGULAR;
    shadowOAM[timeOAM].attr1 = (SCREENWIDTH - 20) | ATTR1_TINY;
    shadowOAM[timeOAM].attr2 = ATTR2_TILEID(11, 4);

    shadowOAM[timeOAM + 1].attr0 = 0 | ATTR0_SQUARE | ATTR0_REGULAR;
    shadowOAM[timeOAM + 1].attr1 = (SCREENWIDTH - 8) | ATTR1_TINY;
    shadowOAM[timeOAM + 1].attr2 = ATTR2_TILEID(timeRemaining/10, 4);
    
    shadowOAM[timeOAM + 2].attr0 = 0 | ATTR0_SQUARE | ATTR0_REGULAR;
    shadowOAM[timeOAM + 2].attr1 = (SCREENWIDTH - 4) | ATTR1_TINY;
    shadowOAM[timeOAM + 2].attr2 = ATTR2_TILEID(timeRemaining%10, 4);
}




// ================= CAT FUNCS ===============

//Initialize the cats
void initCats() {

    for (u8 i = 0; i < CATCOUNT; i++) {
        cats[i].worldRow = player.worldRow-16;
        cats[i].worldCol = 100 + rand() % (360);
        cats[i].screenRow = cats[i].worldRow;
        cats[i].screenCol = cats[i].worldCol;
        cats[i].rdel = 0;
        cats[i].cdel = 1;
        cats[i].height = 24;
        cats[i].width = 32;
        cats[i].active = 1;
        cats[i].aniCounter = rand();
        cats[i].curFrame = 0;
        cats[i].numFrames = 5;
        cats[i].spriteNo = rand() % 2;
        cats[i].catNo = i;
        cats[i].hide = 0;
        if (i < CATCOUNT/2)
            cats[i].facing = 0;
        else
            cats[i].facing = 1;
    }
}

//Handle every-frame actions of cats
void updateCat(CAT* e) {
    if (e->active) {
        if (e->facing) {
            e->worldCol += e->cdel;
            if (e->worldCol >= 512 + 256 -e->width) {
                e->facing = 0;
            }
        } else {
            e->worldCol -= e->cdel;
            if (e->worldCol <= 0) {
                e->facing = 1;
            }
        }
        if (e->aniCounter % 7 == 0) {
            e->curFrame = (e->curFrame + 1) % e->numFrames;
        }
        e->aniCounter++;
        if (collision(player.screenRow, player.screenCol, player.height, player.width,
            e->screenRow+12, e->screenCol, e->height, e->width)) {
            e->active = 0;
            player.health--;
            playSoundB(soundCat,SOUNDCATLEN,SOUNDCATFREQ, 0);
            shadowOAM[enemyOAM + e->catNo].attr0 |= ATTR0_HIDE;
        }

        e->hide = (e->screenCol < - e->width || e->screenCol > 240) ? 1 : 0;
    }
}

//Draw a cat
void drawCat(CAT* e) {
    if (e->hide) {
        shadowOAM[enemyOAM + e->catNo].attr0 |= ATTR0_HIDE;
    } else if (e->active) {
        shadowOAM[enemyOAM + e->catNo].attr0 = (e->screenRow & ROWMASK) | ATTR0_SQUARE | ATTR0_REGULAR;
        shadowOAM[enemyOAM + e->catNo].attr1 = (e->screenCol & COLMASK) | ATTR1_MEDIUM;
        if (e->facing)
            shadowOAM[enemyOAM + e->catNo].attr1 |= ATTR1_HFLIP;
        shadowOAM[enemyOAM + e->catNo].attr2 = ATTR2_TILEID(e->curFrame * 4, 6+((e->spriteNo)*4))
            | ATTR2_PALROW(e->spriteNo + 1);
    }
}




// ================= CAT FUNCS ===============

//Initialize the cheese
void initCheese() {

    for (u8 i = 0; i < CHEESECOUNT; i++) {
        cheese[i].worldRow = SCREENHEIGHT - 24 - rand()%50;
        cheese[i].screenRow = cheese[i].worldRow;
        cheese[i].worldCol = 32 + i * 90;
        cheese[i].screenCol = cheese[i].worldCol;
        cheese[i].height = 10;
        cheese[i].width = 14;
        cheese[i].active = 1;
        cheese[i].hide = 0;
        cheese[i].cheeseNo = i;
    }
}

//Handle every-frame actions of cheese
void updateCheese(CHEESE* c) {
    if (c->active) {
        if (collision(player.screenRow, player.screenCol, player.height, player.width,
            c->screenRow, c->screenCol, c->height, c->width)) {
            c->active = 0;
            playSoundB(cheeseCollected,CHEESECOLLECTEDLEN,CHEESECOLLECTEDFREQ, 0);
            player.cheeseCount++;
            cheeseRemaining--;
            shadowOAM[cheeseOAM + c->cheeseNo].attr0 |= ATTR0_HIDE;
        }

        c->hide = (c->screenCol < - c->width || c->screenCol > 240) ? 1 : 0;
    }
}

//Draw a cheese
void drawCheese(CHEESE* c) {
    if (c->hide) {
        shadowOAM[cheeseOAM + c->cheeseNo].attr0 |= ATTR0_HIDE;
    } else if (c->active) {
        shadowOAM[cheeseOAM + c->cheeseNo].attr0 = (c->screenRow & ROWMASK) | ATTR0_SQUARE | ATTR0_REGULAR;
        shadowOAM[cheeseOAM + c->cheeseNo].attr1 = (c->screenCol & COLMASK) | ATTR1_SMALL;
        shadowOAM[cheeseOAM + c->cheeseNo].attr2 = ATTR2_TILEID(0, 14)
            | ATTR2_PALROW(3);
    }
}

void drawCheeseRemaining() {

        shadowOAM[cheeseRemOAM].attr0 = 16 | ATTR0_WIDE | ATTR0_REGULAR;
        shadowOAM[cheeseRemOAM].attr1 = (SCREENWIDTH - 20) | ATTR1_TINY;
        shadowOAM[cheeseRemOAM].attr2 = ATTR2_TILEID(12, 4);

        shadowOAM[cheeseRemOAM + 1].attr0 = 16 | ATTR0_SQUARE | ATTR0_REGULAR;
        shadowOAM[cheeseRemOAM + 1].attr1 = (SCREENWIDTH - 8) | ATTR1_TINY;
        shadowOAM[cheeseRemOAM + 1].attr2 = ATTR2_TILEID(cheeseRemaining, 4);
}